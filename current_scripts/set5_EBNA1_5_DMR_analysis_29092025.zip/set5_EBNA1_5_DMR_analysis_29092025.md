## Differential Methylation Region (DMR) Analysis
- Data type: Methylated DNA Immunoprecipitation and Sequencing (MeDIP Seq) 
- Based on R package [QSEA](https://bioconductor.org/packages/release/bioc/vignettes/qsea/inst/doc/qsea_tutorial.html)

### Main analysis steps 
1. Prepare data  
2. Run DMR in QSEA  
3. Filtering DMRs  
4. Annotation to DMR  
5. PCA Visualizations  
6. Other Visualizations   
    -Vocalno plot   
    -Heatmap visualzation     
    -circos plots    
    -waveplot on regions    
    -cpg density plot to distance to TTS  


```R
### Load libraries
library(qsea)
library("BSgenome")
library(dplyr)
library(magrittr)
library(tidyverse)
library(BSgenome.Hsapiens.UCSC.hg38)
library("gtools")
library(IRanges)
library(GenomicRanges)
library(org.Hs.eg.db)
library(pheatmap)
library(BiocParallel)
library(readxl)
library(MEDIPS)
library(MEDIPSData)
```


```R
##set up directories
dataDir <- "/home/jupyterlab/data"
mainDir <- "/home/jupyterlab/data/ebv-kd_medip"
inDir <- "/home/jupyterlab/data/ebv-kd_medip/r_inputs"
resDir <- "/home/jupyterlab/data/ebv-kd_medip/r_outputs/DMR_analysis_26092025"
```


```R
#load meta data and qseaSet
setwd(inDir)
sample_meta <- read.delim("sample_meta_final.txt")
final_list <- read.delim("samples_list__merged_bam_092025.txt")
```


```R
#load qseaSet and annotation data
setwd(inDir)
load("qseaSet_blind_merged_bam.RData")
load("hg38_annotation_qsea.RData")
CGIprom = GenomicRanges::intersect(hg38_anno_final$hg38_cpg_islands, hg38_anno_final$hg38_genes_1to5kb,ignore.strand=TRUE)
```


```R
qseaSet_blind
```

    qseaSet
    
    =======================================
    
    79 Samples: 
    
    HANK1_batch1, KAI3_batch1, KHYG_batch1, MD11_batch1, NK92_batch1, NKS1_batch1, NKYS_batch1, S1E11_batch1, S1E12_batch1, S1E13_batch1, S1E21_batch1, S1E22_batch1, S1E23_batch1, S1L51_batch1, S1L52_batch1, S1L53_batch1, S1L71_batch1, S1L72_batch1, S1L73_batch1, S1S21_batch1, S1S22_batch1, S1S23_batch1, S6E11_batch1, S6E12_batch1, S6E21_batch1, S6E22_batch1, S6L51_batch1, S6L52_batch1, S6L61_batch1, S6L62_batch1, S6S21_batch1, S6S22_batch1, SNK1_batch1, SNK6_batch1, T1820_batch1, T2728_batch1, T4748_batch1, TON16_batch1, Undetermined_batch1, YSE11_batch1, YSE12_batch1, YSE13_batch1, YSE21_batch1, YSE22_batch1, YSE23_batch1, YSL51_batch1, YSL52_batch1, YSL53_batch1, YSL61_batch1, YSL62_batch1, YSL63_batch1, YSS21_batch1, YSS22_batch1, YSS23_batch1, YT_batch1, NK1617_batch2, NK4142_batch2, NK4748_batch2, S1L53_batch2, S1L73_batch2, S6E11_batch2, S6E13_batch2, S6E21_batch2, S6E23_batch2, S6L51_batch2, S6L53_batch2, S6L61_batch2, S6L63_batch2, S6S21_batch2, S6S22_batch2, S6S23_batch2, S1L53_batch3, S1L73_batch3, S6E11_batch3, S6E21_batch3, S6L51_batch3, S6L61_batch3, S6S21_batch3, S6S22_batch3
    
    6176526 Regions in 24 chromosomes of BSgenome.Hsapiens.UCSC.hg38
    



```R
qseaSet_final <- qseaSet_blind
```

### 1. Prepare data for DMR
#### 1.1 Prepare meta data
**There are 19 sets of data for DMR analysis.**    
set up the set and prepare the data for DMR analysis


```R
##set up the two group for DMR
sets = unique(sample_meta$set)
sets
length(sets)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'EBNA1_1'</li><li>'EBNA1_2'</li><li>'EBNA1_3'</li><li>'EBNA1_4'</li><li>'EBNA1_5'</li><li>'EBNA1_6'</li><li>'EBNA1_7'</li><li>'EBNA1_8'</li><li>'EBNA1_9'</li><li>'LMP1_10'</li><li>'LMP1_11'</li><li>'LMP1_12'</li><li>'LMP1_13'</li><li>'LMP1_14'</li><li>'LMP1_15'</li><li>'LMP1_16'</li><li>'LMP1_17'</li><li>'LMP1_18'</li><li>'cells_19'</li></ol>




19



```R
############Update the set_number here!!!!!!!!!!!!!!!!
##Extract the samples for the specific set for DMR
set_num = 5
set=sets[set_num]
sample_set = sample_meta %>% filter(set == sets[set_num])
dim(sample_set)
head(sample_set)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6</li><li>5</li></ol>




<table class="dataframe">
<caption>A data.frame: 6 × 5</caption>
<thead>
	<tr><th></th><th scope=col>samples</th><th scope=col>sample_type</th><th scope=col>group</th><th scope=col>set</th><th scope=col>GroupSpace</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>S1S21</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>2</th><td>S1S22</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>3</th><td>S1S23</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>4</th><td>S1E21</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>5</th><td>S1E22</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>6</th><td>S1E23</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
</tbody>
</table>




```R
groups <- unique(sample_set$group)
groups
group1 <- groups[1] ##REF GROUP, usually is the control group
group1
group2 <- groups[2]
group2 
pair <- paste0(group2, "_vs_", group1)
pair
##set up color for plots
group_col <- setNames(c("#4477AA", "#EE6677"), c(group1, group2))
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'NKS1_control'</li><li>'NKS1_EBNA1_KD_2'</li></ol>




'NKS1_control'



'NKS1_EBNA1_KD_2'



'NKS1_EBNA1_KD_2_vs_NKS1_control'



```R
##create a new directory for saving ouputs 
setName=paste0(set, "-of-", pair)
dir.create(file.path(resDir, setName), showWarnings = FALSE)
setDir <- paste0(resDir, "/", setName, sep="")
setDir
dir.create(file.path(setDir, "DMR_analysis"), showWarnings = FALSE)
dmrDir <- paste0(setDir, "/DMR_analysis", sep="")
dmrDir
```


'/home/jupyterlab/data/ebv-kd_medip/r_outputs/DMR_analysis_26092025/EBNA1_5-of-NKS1_EBNA1_KD_2_vs_NKS1_control'



'/home/jupyterlab/data/ebv-kd_medip/r_outputs/DMR_analysis_26092025/EBNA1_5-of-NKS1_EBNA1_KD_2_vs_NKS1_control/DMR_analysis'



```R
##prepare sample data
group1_samples <- sample_set %>% filter(group == group1) %>% .$samples
group1_samples
group2_samples <- sample_set %>% filter(group == group2) %>% .$samples
group2_samples
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1S21'</li><li>'S1S22'</li><li>'S1S23'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1E21'</li><li>'S1E22'</li><li>'S1E23'</li></ol>




```R
group1_list=subset(final_list,final_list$samples %in% group1_samples)
group1_list$samples
group1_list$sample_name 
group2_list=subset(final_list,final_list$samples %in% group2_samples) 
group2_list$samples
group2_list$sample_name 
sample_list=rbind(group1_list,group2_list)
head(sample_list)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1S21'</li><li>'S1S22'</li><li>'S1S23'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1S21_batch1'</li><li>'S1S22_batch1'</li><li>'S1S23_batch1'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1E21'</li><li>'S1E22'</li><li>'S1E23'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'S1E21_batch1'</li><li>'S1E22_batch1'</li><li>'S1E23_batch1'</li></ol>




<table class="dataframe">
<caption>A data.frame: 6 × 9</caption>
<thead>
	<tr><th></th><th scope=col>sample_name</th><th scope=col>file_name</th><th scope=col>group</th><th scope=col>samples</th><th scope=col>batch</th><th scope=col>ID</th><th scope=col>label</th><th scope=col>sample_type</th><th scope=col>cell_type</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>20</th><td>S1S21_batch1</td><td>./bam/ebv-kd_data/batch1/S1S21_merged_sorted.bam</td><td>NKS1 control </td><td>S1S21</td><td>batch1</td><td>NK-S1 SCR#2 set 1  </td><td>S1 S2 1</td><td>NKS1 control   </td><td>NKS1</td></tr>
	<tr><th scope=row>21</th><td>S1S22_batch1</td><td>./bam/ebv-kd_data/batch1/S1S22_merged_sorted.bam</td><td>NKS1 control </td><td>S1S22</td><td>batch1</td><td>NK-S1 SCR#2 set 2  </td><td>S1 S2 2</td><td>NKS1 control   </td><td>NKS1</td></tr>
	<tr><th scope=row>22</th><td>S1S23_batch1</td><td>./bam/ebv-kd_data/batch1/S1S23_merged_sorted.bam</td><td>NKS1 control </td><td>S1S23</td><td>batch1</td><td>NK-S1 SCR#2 set 3  </td><td>S1 S2 3</td><td>NKS1 control   </td><td>NKS1</td></tr>
	<tr><th scope=row>11</th><td>S1E21_batch1</td><td>./bam/ebv-kd_data/batch1/S1E21_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E21</td><td>batch1</td><td>NK-S1 EBNA1#2 set 1</td><td>S1 E2 1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
	<tr><th scope=row>12</th><td>S1E22_batch1</td><td>./bam/ebv-kd_data/batch1/S1E22_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E22</td><td>batch1</td><td>NK-S1 EBNA1#2 set 2</td><td>S1 E2 2</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
	<tr><th scope=row>13</th><td>S1E23_batch1</td><td>./bam/ebv-kd_data/batch1/S1E23_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E23</td><td>batch1</td><td>NK-S1 EBNA1#2 set 3</td><td>S1 E2 3</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
</tbody>
</table>




```R
batch1_lq_samples <- c("S1L53_batch1", "S1L73_batch1", "S6S21_batch1", "S6E11_batch1",
                       "S6E21_batch1", "S6L51_batch1", "S6L61_batch1", "S6S22_batch1")
batch2_lq_samples <- c("S1L53_batch2", "S1L73_batch2", "S6S21_batch2", "S6E11_batch2",
                       "S6E21_batch2", "S6L51_batch2", "S6L61_batch2", "S6S22_batch2")

low_qual_samples <- c(batch1_lq_samples, batch2_lq_samples)#remove low quality samples
dim(sample_list)
sample_list <- sample_list %>% filter(!sample_name %in% low_qual_samples)
dim(sample_list)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6</li><li>9</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6</li><li>9</li></ol>




```R
keep_samples <- qseaSet_final@sampleTable$sample_name %in% sample_list$sample_name
keep_samples
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>TRUE</li><li>TRUE</li><li>TRUE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>TRUE</li><li>TRUE</li><li>TRUE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li><li>FALSE</li></ol>



#### 1.2 Prepare qseaSet data


```R
#subset the qseaSet for the two groups
qseaSet_pair <- qseaSet_final
qseaSet_pair@sampleTable <- qseaSet_pair@sampleTable[keep_samples, ]
dim(qseaSet_pair@sampleTable)
qseaSet_pair@count_matrix <- qseaSet_pair@count_matrix[keep_samples, ]
qseaSet_pair@zygosity <- qseaSet_pair@zygosity[keep_samples, ]
qseaSet_pair@regions <- qseaSet_pair@regions[keep_samples, ]
qseaSet_pair@cnv <- qseaSet_pair@cnv[keep_samples, ]
#don't need to do anything to the parameters
#qseaSet_rm_samples@parameters <- qseaSet_rm_samples@parameters[keep_samples, ]
qseaSet_pair@libraries$file_name <- qseaSet_pair@libraries$file_name[keep_samples, ]
qseaSet_pair@enrichment$parameters <- qseaSet_pair@enrichment$parameters[keep_samples, ]
qseaSet_pair@enrichment$factors <- qseaSet_pair@enrichment$factors[ ,keep_samples]
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6</li><li>9</li></ol>




```R
qseaSet_pair
```

    qseaSet
    
    =======================================
    
    6 Samples: 
    
    S1E21_batch1, S1E22_batch1, S1E23_batch1, S1S21_batch1, S1S22_batch1, S1S23_batch1
    
    469104 Regions in 24 chromosomes of BSgenome.Hsapiens.UCSC.hg38
    



```R
qseaSet_pair@sampleTable
```


<table class="dataframe">
<caption>A data.frame: 6 × 9</caption>
<thead>
	<tr><th></th><th scope=col>sample_name</th><th scope=col>file_name</th><th scope=col>group</th><th scope=col>samples</th><th scope=col>batch</th><th scope=col>ID</th><th scope=col>label</th><th scope=col>sample_type</th><th scope=col>cell_type</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr[,1]&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>S1E21_batch1</th><td>S1E21_batch1</td><td>./bam/ebv-kd_data/batch1/S1E21_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E21</td><td>batch1</td><td>NK-S1 EBNA1#2 set 1</td><td>S1 E2 1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
	<tr><th scope=row>S1E22_batch1</th><td>S1E22_batch1</td><td>./bam/ebv-kd_data/batch1/S1E22_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E22</td><td>batch1</td><td>NK-S1 EBNA1#2 set 2</td><td>S1 E2 2</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
	<tr><th scope=row>S1E23_batch1</th><td>S1E23_batch1</td><td>./bam/ebv-kd_data/batch1/S1E23_merged_sorted.bam</td><td>NKS1 EBNA1 KD</td><td>S1E23</td><td>batch1</td><td>NK-S1 EBNA1#2 set 3</td><td>S1 E2 3</td><td>NKS1 EBNA1 KD 2</td><td>NKS1</td></tr>
	<tr><th scope=row>S1S21_batch1</th><td>S1S21_batch1</td><td>./bam/ebv-kd_data/batch1/S1S21_merged_sorted.bam</td><td>NKS1 control </td><td>S1S21</td><td>batch1</td><td>NK-S1 SCR#2 set 1  </td><td>S1 S2 1</td><td>NKS1 control   </td><td>NKS1</td></tr>
	<tr><th scope=row>S1S22_batch1</th><td>S1S22_batch1</td><td>./bam/ebv-kd_data/batch1/S1S22_merged_sorted.bam</td><td>NKS1 control </td><td>S1S22</td><td>batch1</td><td>NK-S1 SCR#2 set 2  </td><td>S1 S2 2</td><td>NKS1 control   </td><td>NKS1</td></tr>
	<tr><th scope=row>S1S23_batch1</th><td>S1S23_batch1</td><td>./bam/ebv-kd_data/batch1/S1S23_merged_sorted.bam</td><td>NKS1 control </td><td>S1S23</td><td>batch1</td><td>NK-S1 SCR#2 set 3  </td><td>S1 S2 3</td><td>NKS1 control   </td><td>NKS1</td></tr>
</tbody>
</table>




```R
qseaSet_pair@sampleTable <- qseaSet_pair@sampleTable %>% 
    dplyr::select(sample_name, file_name, samples, batch) %>%
    left_join(sample_set, by = "samples") %>% 
    mutate(group = factor(group, levels = c(group1, group2), ordered = T)) %>%
 #   mutate(name_batch = sample_name) %>% 
 #   mutate(sample_name = samples) %>%
    set_rownames(.$sample_name)
```


```R
head(qseaSet_pair@sampleTable)
```


<table class="dataframe">
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>sample_name</th><th scope=col>file_name</th><th scope=col>samples</th><th scope=col>batch</th><th scope=col>sample_type</th><th scope=col>group</th><th scope=col>set</th><th scope=col>GroupSpace</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr[,1]&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;ord&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>S1E21_batch1</th><td>S1E21_batch1</td><td>./bam/ebv-kd_data/batch1/S1E21_merged_sorted.bam</td><td>S1E21</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>S1E22_batch1</th><td>S1E22_batch1</td><td>./bam/ebv-kd_data/batch1/S1E22_merged_sorted.bam</td><td>S1E22</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>S1E23_batch1</th><td>S1E23_batch1</td><td>./bam/ebv-kd_data/batch1/S1E23_merged_sorted.bam</td><td>S1E23</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>S1S21_batch1</th><td>S1S21_batch1</td><td>./bam/ebv-kd_data/batch1/S1S21_merged_sorted.bam</td><td>S1S21</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>S1S22_batch1</th><td>S1S22_batch1</td><td>./bam/ebv-kd_data/batch1/S1S22_merged_sorted.bam</td><td>S1S22</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>S1S23_batch1</th><td>S1S23_batch1</td><td>./bam/ebv-kd_data/batch1/S1S23_merged_sorted.bam</td><td>S1S23</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
</tbody>
</table>




```R
sample_data <- qseaSet_pair@sampleTable
```


```R
table(qseaSet_pair@sampleTable$group)

if(length(unique(sample_data$batch)) > 1) { 
    design_pair=model.matrix(~batch + group, sample_data)
   } else {
    design_pair=model.matrix(~ group, sample_data)
}    
```


    
       NKS1_control NKS1_EBNA1_KD_2 
                  3               3 



```R
design_pair
```


<table class="dataframe">
<caption>A matrix: 6 × 2 of type dbl</caption>
<thead>
	<tr><th></th><th scope=col>(Intercept)</th><th scope=col>group.L</th></tr>
</thead>
<tbody>
	<tr><th scope=row>S1E21_batch1</th><td>1</td><td> 0.7071068</td></tr>
	<tr><th scope=row>S1E22_batch1</th><td>1</td><td> 0.7071068</td></tr>
	<tr><th scope=row>S1E23_batch1</th><td>1</td><td> 0.7071068</td></tr>
	<tr><th scope=row>S1S21_batch1</th><td>1</td><td>-0.7071068</td></tr>
	<tr><th scope=row>S1S22_batch1</th><td>1</td><td>-0.7071068</td></tr>
	<tr><th scope=row>S1S23_batch1</th><td>1</td><td>-0.7071068</td></tr>
</tbody>
</table>



#### 2. RUN DMR in QSEA
- Normalization method: beta


```R
##setup cut-off for DMR
fdr.cutoff = 1
pVal.cutoff = 0.05
deltaBeta.cutoff = 0.2
```


```R
qseaGLM_pair=fitNBglm(qseaSet_pair, design_pair, norm_method="beta", minRowSum=5)
qseaGLM_pair=addContrast(qseaSet_pair,qseaGLM_pair, coef=ncol(design_pair),name="TvN")
```

    selecting regions with at least 5 reads...
    
    deriving normalization factors...
    
    obtaining raw values for 6 samples in 309700 windows
    
    initial fit to estimate dispersion
    
    iteration 1: 
    
    iteration 2: 
    
    iteration 3: 
    
    fitting GLMs
    
    iteration 1: 
    
    ...12/309700 regions converged
    
    iteration 2: 
    
    ...19049/309700 regions converged
    
    iteration 3: 
    
    ...247891/309700 regions converged
    
    iteration 4: 
    
    ...307352/309700 regions converged
    
    iteration 5: 
    
    ...309406/309700 regions converged
    
    iteration 6: 
    
    ...309487/309700 regions converged
    
    iteration 1: 
    
    ...0/309700 regions converged
    
    iteration 2: 
    
    ...694/309700 regions converged
    
    iteration 3: 
    
    ...117484/309700 regions converged
    
    iteration 4: 
    
    ...309472/309700 regions converged
    


#### 3. Filtering the significant/important DMRs
- Get the regions with high frequency beta distribution on samples: mean beta value exists
- cut-offs for significant DMRs: Normal Pvalue < 0.05, DeltaBeta >= 0.2


```R
sig=isSignificant(qseaGLM_pair, fdr_th=fdr.cutoff, direction = "both")
result_all=makeTable(qs=qseaSet_pair, glm=qseaGLM_pair, keep=sig,
                    annotation=hg38_anno_final,
                    samples=getSampleNames(qseaSet_pair),
                    groupMeans=getSampleGroups(qseaSet_pair),
                    norm_method=c("counts", "beta"))
```

    selecting regions from contrast TvN
    
    selected 309700/309700 windows
    
    adding test results from TvN
    
    normalising values in 4 chunks
    
    obtaining raw values for 6 samples in 77425 windows
    
    deriving counts values...
    
    deriving beta values...
    
    obtaining raw values for 6 samples in 77425 windows
    
    deriving counts values...
    
    deriving beta values...
    
    obtaining raw values for 6 samples in 77425 windows
    
    deriving counts values...
    
    deriving beta values...
    
    obtaining raw values for 6 samples in 77425 windows
    
    deriving counts values...
    
    deriving beta values...
    
    adding annotation
    
    creating table...
    



```R
##select rows of beta_means for both group are not empty.
dim(result_all)
beta_means_cols <- grep("_beta_means$", names(result_all), value = TRUE)
result_all_filtered = result_all[complete.cases(result_all[, beta_means_cols]), ]
dim(result_all_filtered)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>309700</li><li>41</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>90769</li><li>41</li></ol>




```R
colnames(result_all_filtered)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'chr'</li><li>'window_start'</li><li>'window_end'</li><li>'CpG_density'</li><li>'hg38_genes_1to5kb'</li><li>'hg38_genes_promoters'</li><li>'hg38_genes_cds'</li><li>'hg38_genes_5UTRs'</li><li>'hg38_genes_exons'</li><li>'hg38_genes_firstexons'</li><li>'hg38_genes_introns'</li><li>'hg38_genes_intronexonboundaries'</li><li>'hg38_genes_exonintronboundaries'</li><li>'hg38_genes_3UTRs'</li><li>'hg38_genes_intergenic'</li><li>'hg38_cpg_islands'</li><li>'hg38_cpg_shores'</li><li>'hg38_cpg_shelves'</li><li>'hg38_cpg_inter'</li><li>'hg38_enhancers_fantom'</li><li>'hg38_basicgenes'</li><li>'hg38_cpgs'</li><li>'TvN_log2FC'</li><li>'TvN_pvalue'</li><li>'TvN_adjPval'</li><li>'S1E21_batch1_counts'</li><li>'S1E22_batch1_counts'</li><li>'S1E23_batch1_counts'</li><li>'S1S21_batch1_counts'</li><li>'S1S22_batch1_counts'</li><li>'S1S23_batch1_counts'</li><li>'S1E21_batch1_beta'</li><li>'S1E22_batch1_beta'</li><li>'S1E23_batch1_beta'</li><li>'S1S21_batch1_beta'</li><li>'S1S22_batch1_beta'</li><li>'S1S23_batch1_beta'</li><li>'NKS1_control_counts_means'</li><li>'NKS1_EBNA1_KD_2_counts_means'</li><li>'NKS1_control_beta_means'</li><li>'NKS1_EBNA1_KD_2_beta_means'</li></ol>




```R
colnames(result_all_filtered) <- gsub("_batch1|_batch2|_batch3", "", colnames(result_all_filtered))
```


```R
colnames(result_all_filtered)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'chr'</li><li>'window_start'</li><li>'window_end'</li><li>'CpG_density'</li><li>'hg38_genes_1to5kb'</li><li>'hg38_genes_promoters'</li><li>'hg38_genes_cds'</li><li>'hg38_genes_5UTRs'</li><li>'hg38_genes_exons'</li><li>'hg38_genes_firstexons'</li><li>'hg38_genes_introns'</li><li>'hg38_genes_intronexonboundaries'</li><li>'hg38_genes_exonintronboundaries'</li><li>'hg38_genes_3UTRs'</li><li>'hg38_genes_intergenic'</li><li>'hg38_cpg_islands'</li><li>'hg38_cpg_shores'</li><li>'hg38_cpg_shelves'</li><li>'hg38_cpg_inter'</li><li>'hg38_enhancers_fantom'</li><li>'hg38_basicgenes'</li><li>'hg38_cpgs'</li><li>'TvN_log2FC'</li><li>'TvN_pvalue'</li><li>'TvN_adjPval'</li><li>'S1E21_counts'</li><li>'S1E22_counts'</li><li>'S1E23_counts'</li><li>'S1S21_counts'</li><li>'S1S22_counts'</li><li>'S1S23_counts'</li><li>'S1E21_beta'</li><li>'S1E22_beta'</li><li>'S1E23_beta'</li><li>'S1S21_beta'</li><li>'S1S22_beta'</li><li>'S1S23_beta'</li><li>'NKS1_control_counts_means'</li><li>'NKS1_EBNA1_KD_2_counts_means'</li><li>'NKS1_control_beta_means'</li><li>'NKS1_EBNA1_KD_2_beta_means'</li></ol>




```R
result_DMR <- result_all_filtered %>% filter(TvN_pvalue <= 0.05)
dim(result_DMR)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>2583</li><li>41</li></ol>




```R
beta_means_cols
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'NKS1_control_beta_means'</li><li>'NKS1_EBNA1_KD_2_beta_means'</li></ol>




```R
#### Calculate delta beta and apply for DMR
result_DMR$deltaBeta <- result_DMR[, beta_means_cols[2]] - result_DMR[, beta_means_cols[1]]
result_DMR_filtered <- result_DMR %>% filter(abs(deltaBeta) >= 0.2)
dim(result_DMR_filtered)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>1756</li><li>42</li></ol>




```R
result_DMR_filtered$ID=1:nrow(result_DMR_filtered)
result_DMR_bed=result_DMR_filtered %>% dplyr::select("chr", "window_start", "window_end", "ID")
colnames(result_DMR_bed)=c('chrom', 'chromStart', 'chromEnd','ID')
```


```R
result_all_filtered$deltaBeta <- result_all_filtered[, beta_means_cols[2]] - result_all_filtered[, beta_means_cols[1]]
result_all_filtered$ID=1:nrow(result_all_filtered)
result_all_bed=result_all_filtered %>% dplyr::select("chr", "window_start", "window_end", "ID")
colnames(result_all_bed)=c('chrom', 'chromStart', 'chromEnd','ID')
```


```R
#save the bed files for annotation
setwd(dmrDir)
write.table(result_DMR_bed, file= paste0(pair,".bed", sep=""), sep="\t", quote=F, row.names=F, col.names=F)
write.table(result_all_bed, file= paste0(pair,"_all.bed", sep=""), sep="\t", quote=F, row.names=F, col.names=F)
```

### 4. Annotation to DMR and all regions


```R
library(ChIPseeker)
library(TxDb.Hsapiens.UCSC.hg38.knownGene)
txdb <- TxDb.Hsapiens.UCSC.hg38.knownGene
##Annotation the DMR 
setwd(dmrDir)
peakAnno_pair =annotatePeak(paste0(pair,".bed", sep=""), 
                          tssRegion=c(-3000,3000),
                          TxDb=txdb, annoDb="org.Hs.eg.db")

peakAnno_pair=as.data.frame(peakAnno_pair)
result_DMR_filtered=left_join(result_DMR_filtered, peakAnno_pair,by=c('ID'='V4'))
```

    
    
    ChIPseeker v1.38.0
    
    If you use ChIPseeker in published research, please cite:
    Qianwen Wang, Ming Li, Tianzhi Wu, Li Zhan, Lin Li, Meijun Chen, Wenqin Xie, Zijing Xie, Erqiang Hu, Shuangbin Xu, Guangchuang Yu. Exploring epigenomic datasets by ChIPseeker. Current Protocols 2022, 2(10): e585
    
    Loading required package: GenomicFeatures
    


    >> loading peak file...				 2025-09-30 07:38:48 
    >> preparing features information...		 2025-09-30 07:38:48 
    >> identifying nearest features...		 2025-09-30 07:38:49 
    >> calculating distance from peak to TSS...	 2025-09-30 07:38:49 
    >> assigning genomic annotation...		 2025-09-30 07:38:49 
    >> adding gene annotation...			 2025-09-30 07:39:15 


    'select()' returned 1:many mapping between keys and columns
    


    >> assigning chromosome lengths			 2025-09-30 07:39:16 
    >> done...					 2025-09-30 07:39:16 



```R
##Annotation the all filtered regions 
setwd(dmrDir)
peakAnno_pair =annotatePeak(paste0(pair,"_all.bed", sep=""), 
                          tssRegion=c(-3000,3000),
                          TxDb=txdb, annoDb="org.Hs.eg.db")

peakAnno_pair=as.data.frame(peakAnno_pair)
result_all_filtered=left_join(result_all_filtered, peakAnno_pair,by=c('ID'='V4'))
```

    >> loading peak file...				 2025-09-30 07:39:16 
    >> preparing features information...		 2025-09-30 07:39:16 
    >> identifying nearest features...		 2025-09-30 07:39:16 
    >> calculating distance from peak to TSS...	 2025-09-30 07:39:17 
    >> assigning genomic annotation...		 2025-09-30 07:39:17 
    >> adding gene annotation...			 2025-09-30 07:39:22 


    'select()' returned 1:many mapping between keys and columns
    


    >> assigning chromosome lengths			 2025-09-30 07:39:23 
    >> done...					 2025-09-30 07:39:23 



```R
#save the DMR results in table
setwd(dmrDir)
write.table(result_DMR, paste0("results_DMR_sig_", pair, ".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
write.table(result_all_filtered, paste0("results_all_filtered_", pair, ".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
write.table(result_DMR_filtered, paste0("results_DMR_filtered_", pair, ".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
```

### 5. PCA Visualization
 - 5.1 PCA plot based on the top 2000 variable regions
 - 5.2 PCA plot based on CpG Island Promoters
 - 5.3 PCA plot based on CpG Island 

#### 5.1 PCA plot based on the top varible regions


```R
pca_topVar=getPCA(qseaSet_pair, norm_method="beta", topVar=1000)
plotPCA_topVar <- plotPCA(pca_topVar, bg=col, main="PCA of Top Variable Regions")
pcaData = data.frame(plotPCA_topVar$x, plotPCA_topVar$y)
colnames(pcaData) <- c("PC1", "PC2")
rownames(pcaData) <- pca_topVar@sample_names
pcaData <- pcaData %>% mutate(sample_name = rownames(.)) %>% left_join(sample_data, by="sample_name")
pcaData$group <- factor(pcaData$group, levels = c(group1, group2), ordered = T)
```

    Warning message in symbols(x = x, y = y, fg = fgColor, bg = bgColor, pch = 20, xlab = paste0("PC", :
    “supplied color is neither numeric nor character”



    
![png](output_46_1.png)
    



```R
head(pcaData)
```


<table class="dataframe">
<caption>A data.frame: 6 × 10</caption>
<thead>
	<tr><th></th><th scope=col>PC1</th><th scope=col>PC2</th><th scope=col>sample_name</th><th scope=col>file_name</th><th scope=col>samples</th><th scope=col>batch</th><th scope=col>sample_type</th><th scope=col>group</th><th scope=col>set</th><th scope=col>GroupSpace</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr[,1]&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;ord&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>-3.470010</td><td> 5.2451490</td><td>S1E21_batch1</td><td>./bam/ebv-kd_data/batch1/S1E21_merged_sorted.bam</td><td>S1E21</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>2</th><td>-2.687293</td><td> 1.9566968</td><td>S1E22_batch1</td><td>./bam/ebv-kd_data/batch1/S1E22_merged_sorted.bam</td><td>S1E22</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>3</th><td>-4.472737</td><td>-5.9891547</td><td>S1E23_batch1</td><td>./bam/ebv-kd_data/batch1/S1E23_merged_sorted.bam</td><td>S1E23</td><td>batch1</td><td>NKS1 EBNA1 KD 2</td><td>NKS1_EBNA1_KD_2</td><td>EBNA1_5</td><td>NKS1 EBNA1 KD 2</td></tr>
	<tr><th scope=row>4</th><td> 4.360294</td><td>-0.4625654</td><td>S1S21_batch1</td><td>./bam/ebv-kd_data/batch1/S1S21_merged_sorted.bam</td><td>S1S21</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>5</th><td> 2.389130</td><td>-1.0720128</td><td>S1S22_batch1</td><td>./bam/ebv-kd_data/batch1/S1S22_merged_sorted.bam</td><td>S1S22</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
	<tr><th scope=row>6</th><td> 3.880616</td><td> 0.3218871</td><td>S1S23_batch1</td><td>./bam/ebv-kd_data/batch1/S1S23_merged_sorted.bam</td><td>S1S23</td><td>batch1</td><td>NKS1 control   </td><td>NKS1_control   </td><td>EBNA1_5</td><td>NKS1 control   </td></tr>
</tbody>
</table>




```R
pcaData %<>% mutate(name_batch = sample_name) %>% mutate(sample_name = samples) 
```


```R
options(repr.plot.width = 12, repr.plot.height = 10)
fig_PCA_topVar <- ggplot(pcaData, aes(PC1, PC2, color=group, label = sample_name)) +
     geom_point(size=4) +
     geom_text(hjust=0, vjust=0, size=3) +
     xlab("PC1") +
     ylab("PC2") + 
#     coord_fixed() +
     scale_x_continuous(limits = c(min(pcaData$PC1)-5 ,max(pcaData$PC1)+5)) +
     scale_color_manual(values = group_col) +
     ggtitle("PCA plot of Top 1000 Variable Regions") +
     theme_bw() +
     theme(plot.title = element_text(size = 18, family = "Tahoma", face = "bold"),
        text = element_text(size = 16, family = "Tahoma"))

suppressWarnings(print(fig_PCA_topVar))
```


    
![png](output_49_0.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("plotPCA_top1000VARs_", pair, ".tiff", sep=""), width = 5500, height = 4000, units = 'px', compression = "zip", res = 600)
fig_PCA_topVar
dev.off()
write.table(pcaData, paste0("pcaData_top1000VARs_", pair,".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
```


<strong>pdf:</strong> 2


#### 5.2 PCA plot based on CpG Island Promoters


```R
pca_cgip=getPCA(qseaSet_pair, norm_method="beta", ROIs=CGIprom)
plotPCA_CpG_island_promoters <- plotPCA(pca_cgip, bg=col, main="PCA plot based on CpG Island Promoters")
pcaData = data.frame(plotPCA_CpG_island_promoters$x, plotPCA_CpG_island_promoters$y)
colnames(pcaData) <- c("PC1", "PC2")
rownames(pcaData) <- pca_cgip@sample_names
pcaData <- pcaData %>% mutate(sample_name = rownames(.)) %>% left_join(sample_data, by="sample_name")
pcaData$group <- factor(pcaData$group, levels = c(group1, group2), ordered = T)
```

    Warning message in symbols(x = x, y = y, fg = fgColor, bg = bgColor, pch = 20, xlab = paste0("PC", :
    “supplied color is neither numeric nor character”



    
![png](output_52_1.png)
    



```R
pcaData %<>% mutate(name_batch = sample_name) %>% mutate(sample_name = samples) 
```


```R
options(repr.plot.width = 12, repr.plot.height = 10)
fig_plotPCA_CpG_island_promoters  <- ggplot(pcaData, aes(PC1, PC2, color=group, label = sample_name)) +
     geom_point(size=4) +
     geom_text(hjust=0, vjust=0, size=3) +
     xlab("PC1") +
     ylab("PC2") + 
#     coord_fixed() +
     scale_x_continuous(limits = c(min(pcaData$PC1)-5 ,max(pcaData$PC1)+5)) +
     scale_color_manual(values = group_col) +
     ggtitle("PCA plot based on CpG Island Promoters") +
     theme_bw() +
     theme(plot.title = element_text(size = 18, family = "Tahoma", face = "bold"),
        text = element_text(size = 16, family = "Tahoma"))

suppressWarnings(print(fig_plotPCA_CpG_island_promoters))

```


    
![png](output_54_0.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("plotPCA_CpG_Island_Promoters_", pair, ".tiff", sep=""), width = 5500, height = 4000, units = 'px', compression = "zip", res = 600)
fig_plotPCA_CpG_island_promoters
dev.off()
write.table(pcaData, paste0("plotPCA_CpG_Island_Promoters_", pair,".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
```


<strong>pdf:</strong> 2


#### 5.3 PCA plot based on CpG Island


```R
pca_cgi_cpg=getPCA(qseaSet_pair,norm_method="beta", ROIs=hg38_anno_final$hg38_cpg_islands)
plotPCA_CpG_island <- plotPCA(pca_cgi_cpg, main="PCA plot based on CpG Island")
pcaData = data.frame(plotPCA_CpG_island$x, plotPCA_CpG_island$y)
colnames(pcaData) <- c("PC1", "PC2")
rownames(pcaData) <- pca_cgi_cpg@sample_names
pcaData <- pcaData %>% mutate(sample_name = rownames(.)) %>% left_join(sample_data, by="sample_name")
pcaData$group <- factor(pcaData$group, levels = c(group1, group2), ordered = T)
```


    
![png](output_57_0.png)
    



```R
pcaData %<>% mutate(name_batch = sample_name) %>% mutate(sample_name = samples) 
```


```R
options(repr.plot.width = 15, repr.plot.height = 10)
fig_plotPCA_CpG_island <- ggplot(pcaData, aes(PC1, PC2, color=group, label = sample_name)) +
     geom_point(size=4) +
     geom_text(hjust=0, vjust=0, size=3) +
     xlab("PC1") +
     ylab("PC2") + 
#     coord_fixed() +
     scale_x_continuous(limits = c(min(pcaData$PC1)-5 ,max(pcaData$PC1)+5)) +
 #    scale_y_continuous(limits = c(-15,15)) +
     scale_color_manual(values = group_col) +
     ggtitle("PCA plot based on CpG Island") +
     theme_bw() +
     theme(plot.title = element_text(size = 20, family = "Tahoma", face = "bold"),
        text = element_text(size = 16, family = "Tahoma"),
          legend.title = element_text(size = 16, family = "Tahoma", face = "bold"),
          legend.position='right')

suppressWarnings(print(fig_plotPCA_CpG_island))
```


    
![png](output_59_0.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("plotPCA_CpG_Island_", pair, ".tiff", sep=""), width = 5500, height = 4000, units = 'px', compression = "zip", res = 600)
fig_plotPCA_CpG_island
dev.off()
write.table(pcaData, paste0("plotPCA_CpG_Island_", pair,".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
```


<strong>pdf:</strong> 2


### 6.1 Visualization: Volcano plot
Volcano plot of the all filtered regions  


```R
#colnames(result_all_filtered)
```


```R
library(EnhancedVolcano)
volcano_plot <- 
  EnhancedVolcano(result_all_filtered,
                  lab = rownames(result_all_filtered),
                  selectLab = c(""),
                  #   labSize = 3.0,
                  x = 'deltaBeta',
                  y = 'TvN_pvalue',
                  pCutoff = pVal.cutoff,
                  FCcutoff = deltaBeta.cutoff,
                  xlab = bquote(Delta*beta),
                  ylab = bquote(-log[10]~P), 
                  legendLabels=c(bquote(P >= 0.05 ~ "&&" ~ "|"*Delta*beta*"|" <= 0.2), 
                                 bquote(P >= 0.05 ~ "&&" ~ "|"*Delta*beta*"|" >= 0.2),       
                                 bquote(P <= 0.05 ~ "&&" ~ "|"*Delta*beta*"|" <= 0.2),
                                 bquote(P <= 0.05 ~ "&&" ~ "|"*Delta*beta*"|" >= 0.2)),
                  legendPosition = 'right',
                  legendLabSize = 16,
                  legendIconSize = 5.0,
                  cutoffLineType = 'twodash',
                  cutoffLineWidth = 0.8,
                  title = paste0("Differential methylation of ", group2, " v.s. ", group1, sep=""),
                  ylim = c(0, 5),
                  xlim = c(-0.6, 0.6),
                  subtitle = NULL 
                  #               ylim = c(0, 100)
  )  
options(repr.plot.width = 15, repr.plot.height = 10)
volcano_plot
```

    Loading required package: ggrepel
    



    
![png](output_63_1.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("Volcano_plot_DMRs_", pair, ".tiff", sep=""), width = 6500, height = 4000, units = 'px', compression = "zip", res = 600)
volcano_plot 
dev.off()
```


<strong>pdf:</strong> 2


### 6.2 Visualization: Heatmap
Heatmap of beta values of the important DMRs  


```R
#get beta value
hm_beta=result_DMR_filtered %>% dplyr::select(ends_with('_beta'))
colnames(hm_beta)=gsub('_beta$','',colnames(hm_beta))
```


```R
sample_anno=data.frame(sample_data$group)                                                
colnames(sample_anno) <- "Group"
#sample_anno <- sample_anno %>% mutate(Group = recode(Group, "Normal" = "Control", "EP" = "nTNKL", "NK" = "ENKTL"))    
rownames(sample_anno)=colnames(hm_beta)
```


```R
options(repr.plot.width = 25, repr.plot.height = 15)
hm=pheatmap(hm_beta, show_colnames = T, show_rownames = F, 
           annotation_col = sample_anno, annotation_colors = list(Group=group_col), cluster_cols = T, 
           clustering_distance_cols = "euclidean", 
           clustering_method = "ward.D")
hm
```

    Warning message:
    “The input is a data frame, convert it to the matrix.”



    
![png](output_68_1.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("HM_pheatmap_DMR_beta_", pair, ".tiff", sep=""), width = 7500, height = 4000, units = 'px', compression = "zip", res = 600)
hm
dev.off()
```


<strong>pdf:</strong> 2


### PCA plot using heatmap/DMR data


```R
library(pcaMethods)
library(ggplot2)
```

    
    Attaching package: ‘pcaMethods’
    
    
    The following object is masked from ‘package:stats’:
    
        loadings
    
    



```R
pca_result = pca(t(hm_beta), method = "nipals", nPcs = 2, scale = "uv")
scores = scores(pca_result)
pca_data = as.data.frame(scores)
pca_data <- cbind(pca_data, sample_anno)
pca_data$sample_name = rownames(pca_data)

head(pca_data)
```


<table class="dataframe">
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>PC1</th><th scope=col>PC2</th><th scope=col>Group</th><th scope=col>sample_name</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;ord&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>S1E21</th><td>-35.19236</td><td>-16.8352800</td><td>NKS1_EBNA1_KD_2</td><td>S1E21</td></tr>
	<tr><th scope=row>S1E22</th><td>-32.62789</td><td> 13.6582519</td><td>NKS1_EBNA1_KD_2</td><td>S1E22</td></tr>
	<tr><th scope=row>S1E23</th><td>-25.33006</td><td>  2.3578188</td><td>NKS1_EBNA1_KD_2</td><td>S1E23</td></tr>
	<tr><th scope=row>S1S21</th><td> 32.32556</td><td> -7.4062886</td><td>NKS1_control   </td><td>S1S21</td></tr>
	<tr><th scope=row>S1S22</th><td> 29.70629</td><td>  6.3808039</td><td>NKS1_control   </td><td>S1S22</td></tr>
	<tr><th scope=row>S1S23</th><td> 31.11845</td><td>  0.5952082</td><td>NKS1_control   </td><td>S1S23</td></tr>
</tbody>
</table>




```R
options(repr.plot.width = 12, repr.plot.height = 10)
fig_PCA_topDMR <- ggplot(pca_data, aes(PC1, PC2, color=Group, label = sample_name)) +
     geom_point(size=4) +
     geom_text(hjust=0, vjust=0, size=3) +
     xlab("PC1") +
     ylab("PC2") + 
#     coord_fixed() +
     scale_x_continuous(limits = c(min(pca_data$PC1)-5 ,max(pca_data$PC1)+5)) +
     scale_color_manual(values = group_col) +
     ggtitle("PCA plot of Top DMRs") +
     theme_bw() +
     theme(plot.title = element_text(size = 18, family = "Tahoma", face = "bold"),
        text = element_text(size = 16, family = "Tahoma"))

suppressWarnings(print(fig_PCA_topDMR))
```


    
![png](output_73_0.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("plotPCA_topDMRs_", pair, ".tiff", sep=""), width = 5500, height = 4000, units = 'px', compression = "zip", res = 600)
fig_PCA_topDMR
dev.off()
write.table(pca_data, paste0("pcaData_topDMRs_", pair,".txt", sep=""), sep="\t", quote = FALSE, row.names=F, col.names = T)
```


<strong>pdf:</strong> 2


### 6.3 Visualization: circos plot
https://jokergoo.github.io/circlize_book/book/legends.html


```R
library(circlize)
library(ComplexHeatmap)
```


```R
##use hg38 
setwd(inDir)
cytoband.df.1 <- read.table("cytoBand_hg38.txt", colClasses = c("character", "numeric", "numeric", "character","character"), sep = "\t")
# Remove the unmapped areas: remove chromosome names that end in _alt or _random or start with chrUn:
cytoband.df.2 <- cytoband.df.1 %>%
  dplyr::filter(!str_detect(V1, "chrUn")) %>%
  dplyr::filter(!str_detect(V1, "_alt")) %>%
  dplyr::filter(!str_detect(V1, "_random"))
```


```R
##prepare data
data_hyper <- result_DMR_filtered %>% filter(deltaBeta > 0) %>% dplyr::select(-ends_with('beta')) %>% dplyr::select(-ends_with('counts'))
data_hypo <- result_DMR_filtered %>% filter(TvN_log2FC < 0) %>% dplyr::select(-ends_with('beta')) %>% dplyr::select(-ends_with('counts'))
DMR_hyper <- data_hyper %>% dplyr::select("chr", "window_start", "window_end")
DMR_hypo <- data_hypo %>% dplyr::select("chr", "window_start", "window_end") 
colnames(DMR_hyper) <- c("chr", "start", "end")
colnames(DMR_hypo) <- c("chr", "start", "end")
bed_list = list(DMR_hyper, DMR_hypo)
```


```R
circos.initializeWithIdeogram(cytoband.df.2,chromosome.index = paste0("chr", 1:22))
circos.genomicRainfall(bed_list, pch = 16, cex = 0.4, col = c("#FF000080", "#0000FF80"))
circos.genomicDensity(bed_list[[1]], col = c("#FF000080"), track.height = 0.1)
circos.genomicDensity(bed_list[[2]], col = c("#0000FF80"), track.height = 0.1)
#add legend
lgd = Legend(at = c("Hypermethylated", "Hypomethylated"), type = "points", 
    legend_gp = gpar(col = c("#FF000080", "#0000FF80")), title_position = "topleft", 
    title = "Methylation level")
draw(lgd, x = unit(4, "cm"), y = unit(4, "cm"), just = c("left", "bottom"))
```


    
![png](output_79_0.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("circos_plot_rainfall_density_", pair, ".tiff", sep=""), width = 7500, height = 5000, units = 'px', compression = "zip", res = 600)
circos.initializeWithIdeogram(cytoband.df.2,chromosome.index = paste0("chr", 1:22))
circos.genomicRainfall(bed_list, pch = 16, cex = 0.4, col = c("#FF000080", "#0000FF80"))
circos.genomicDensity(bed_list[[1]], col = c("#FF000080"), track.height = 0.1)
circos.genomicDensity(bed_list[[2]], col = c("#0000FF80"), track.height = 0.1)
draw(lgd, x = unit(4, "cm"), y = unit(4, "cm"), just = c("left", "bottom"))
dev.off()
```


<strong>pdf:</strong> 2


### 6.4 Visualization: Waveplot for global methylation level


```R
#perpare data
df_group1 <- result_DMR_filtered[, c( paste0(group1, "_beta_means"), "hg38_genes_promoters", "hg38_genes_5UTRs", "hg38_genes_exons", "hg38_genes_introns", "hg38_genes_3UTRs", "hg38_genes_intergenic")]  
colnames(df_group1) <- c("mean_beta", "hg38_genes_promoters", "hg38_genes_5UTRs", "hg38_genes_exons", "hg38_genes_introns", "hg38_genes_3UTRs", "hg38_genes_intergenic")
df_group1 <- df_group1 %>% mutate(Group = group1) 

df_group2 <- result_DMR_filtered[, c( paste0(group2, "_beta_means"), "hg38_genes_promoters", "hg38_genes_5UTRs", "hg38_genes_exons", "hg38_genes_introns", "hg38_genes_3UTRs", "hg38_genes_intergenic")]  
colnames(df_group2) <- c("mean_beta", "hg38_genes_promoters", "hg38_genes_5UTRs", "hg38_genes_exons", "hg38_genes_introns", "hg38_genes_3UTRs", "hg38_genes_intergenic")
df_group2 <- df_group2 %>% mutate(Group = group2) 

combined_df <- bind_rows(df_group1, df_group2)
```


```R
#define the function to extract the regions
extract_region_position <- function(column, region_name) {
  genomic_position <- as.numeric(gsub(".*:([0-9]+).*", "\\1", column))
  
  extracted_df <- data.frame(
    mean_beta = combined_df$mean_beta,
    Region = region_name,
    Genomic_position = genomic_position,
    Group = combined_df$Group
  )
    extracted_df <- extracted_df[!is.na(extracted_df$Genomic_position), ]
  
  return(extracted_df)
}
```


```R
promoter_data <- extract_region_position(combined_df$hg38_genes_promoters, "Promoter")
utr5_data <- extract_region_position(combined_df$hg38_genes_5UTRs, "5'-UTR")
exon_data <- extract_region_position(combined_df$hg38_genes_exons, "Exon")
intron_data <- extract_region_position(combined_df$hg38_genes_introns, "Intron")
utr3_data <- extract_region_position(combined_df$hg38_genes_3UTRs, "3'-UTR")
intergenic_data <- extract_region_position(combined_df$hg38_genes_intergenic, "Intergenic")
```


```R
final_df <- rbind(promoter_data, utr5_data, exon_data, intron_data, utr3_data, intergenic_data)

final_df <- final_df %>%
  filter(!is.na(mean_beta) & !is.na(Genomic_position)) %>%
  mutate(Region = factor(Region, levels = c("Promoter", "5'-UTR", "Intergenic", "Exon", "Intron", "3'-UTR")),
         Group = factor(Group, levels = c(group1, group2)))

```


```R
waveplot_regions <- ggplot(final_df, aes(x = Genomic_position, y = mean_beta, group = interaction(Region, Group), color = Group)) +
  geom_smooth(method = "loess", se = FALSE, size = 1.5, span = 0.3) +  
  theme_minimal(base_size = 14) + 
  labs(title = "Methylation Level Across Genomic Regions",
       x = "Genomic Position",
       y = "Methylation Level") +  
  theme(
    strip.background = element_blank(),  
    strip.text.x = element_text(size = 12),  
    axis.text.x = element_blank(),  
    axis.ticks.x = element_blank(),  
    legend.position = "right",  
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.2),  
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),  
    plot.margin = unit(c(1, 1, 1, 1), "lines")
  ) +
  facet_wrap(~ Region, scales = "free_x", nrow = 1, strip.position = "bottom", 
             labeller = label_value) +  
  theme(panel.spacing = unit(0.1, "lines")) +
  scale_color_manual(values = group_col)
waveplot_regions
```

    Warning message:
    “[1m[22mUsing `size` aesthetic for lines was deprecated in ggplot2 3.4.0.
    [36mℹ[39m Please use `linewidth` instead.”
    [1m[22m`geom_smooth()` using formula = 'y ~ x'



    
![png](output_86_1.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("waveplot_regions_v1_", pair, ".tiff", sep=""), width = 7500, height = 4000, units = 'px', compression = "zip", res = 600)
waveplot_regions
dev.off()
```

    [1m[22m`geom_smooth()` using formula = 'y ~ x'



<strong>pdf:</strong> 2



```R
waveplot_regions_v2 <- ggplot(final_df, aes(x = Genomic_position, y = mean_beta, group = interaction(Region, Group), color = Group)) +
  geom_smooth(method = "loess", se = FALSE, size = 1.5, span = 0.3) +  
  theme_minimal(base_size = 14) + 
  labs(title = "Methylation Level Across Genomic Regions",
       x = "Genomic Position",
       y = "Methylation Level") +  
    scale_y_continuous(limits = c(0, 4), expand = c(0, 0)) +
  theme(
    strip.background = element_blank(), 
  #  strip.text.x = element_text(angle = 45),
  #  strip.background = element_rect(fill = "grey"),
    strip.text.x = element_text(size = 12, angle = 90),  
    axis.text.x = element_blank(),  
    axis.ticks.x = element_blank(),  
    legend.position = "right",  
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.2),  
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(),  
    plot.margin = unit(c(1, 1, 1, 1), "lines")
  ) +
  facet_grid(~Region, scales="free", space="free_x", labeller = label_value) +
#  facet_wrap(~ Region, nrow = 1, strip.position = "bottom", space="free_x", 
#             labeller = label_value) +  
  theme(panel.spacing = unit(0.2, "lines")) +
  scale_color_manual(values = group_col)

options(repr.plot.width = 25, repr.plot.height = 15)
waveplot_regions_v2
```

    [1m[22m`geom_smooth()` using formula = 'y ~ x'



    
![png](output_88_1.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("waveplot_regions_v2_scale_x_", pair, ".tiff", sep=""), width = 8000, height = 4000, units = 'px', compression = "zip", res = 600)
waveplot_regions_v2
dev.off()
```

    [1m[22m`geom_smooth()` using formula = 'y ~ x'



<strong>pdf:</strong> 2


### 6.5 Visualization: CPG Density plot of DMR regions cross the Distance to TSS


```R
cpg_data <- result_DMR_filtered %>% 
    dplyr::select(-(ends_with('_beta'))) %>%
    dplyr::select(-(ends_with('counts')))
```


```R
dim(cpg_data)
cpg_data <- cpg_data %>%  
    dplyr::select(ID, deltaBeta, SYMBOL, distanceToTSS) %>%
    mutate(methylation = ifelse(deltaBeta > 0, "Hypermethylated", "Hypomethylated")) 

```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>1756</li><li>48</li></ol>




```R
meth_col <- c("#FF000080", "#0000FF80")
```


```R
options(repr.plot.width = 15, repr.plot.height = 15)
cpg_density <- ggplot(cpg_data, aes(x=distanceToTSS, color=methylation))+
  geom_density(size = 1.5) +
   scale_color_manual(values = meth_col) +
 # geom_histogram(aes(y=..density..) +
  xlim(-50000, 50000) + 
  ggtitle(paste0("CPG density plots of ", group2, " v.s. ", group1)) +
  xlab("Distance to TSS") + ylab("CPG Frequency") + 
  theme_bw()+
  theme(legend.position="right", axis.title.y = element_text(size=13),
        axis.text.x = element_text(size=10), axis.text.y = element_text(size=10) )
 
cpg_density
```

    Warning message:
    “[1m[22mRemoved 307 rows containing non-finite outside the scale range
    (`stat_density()`).”



    
![png](output_94_1.png)
    



```R
#save figures
setwd(dmrDir)
tiff(paste0("CPG_density_plots_of_Distance_to_TSS_", pair, ".tiff", sep=""), width = 5500, height = 4000, units = 'px', compression = "zip", res = 600)
cpg_density
dev.off()
```

    Warning message:
    “[1m[22mRemoved 307 rows containing non-finite outside the scale range
    (`stat_density()`).”



<strong>pdf:</strong> 2


### End of DMR analysis
